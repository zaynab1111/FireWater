#include <iostream>
#include <cstdlib>
#include "GameEngine.h"

int allocationCount = 0;

void* operator new(size_t size) {
    allocationCount++;
    return malloc(size);
}

void operator delete(void* ptr) noexcept {
    allocationCount--;
    free(ptr);
}

int main() {
    {
        GameEngine engine;
        engine.run();
    } // engine destructor runs here before we print

    std::cout << "Unfreed allocations: " << allocationCount << std::endl;
    system("pause"); // keeps console open so you can read it

    return 0;
}